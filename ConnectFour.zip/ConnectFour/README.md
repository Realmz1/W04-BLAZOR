# Connect Four (Blazor)

A two-player Connect Four game built with a .NET 8 **Blazor Web App** (Interactive Server render mode).
Created for the CSE 325 W04 assignment, following the Microsoft Learn module
*[Build a Connect Four game with Blazor](https://learn.microsoft.com/en-us/training/modules/dotnet-connect-four/)*.

## How to play

1. Player 1 is **Red**, Player 2 is **Yellow**. Red goes first.
2. Click the ▼ button above a column to drop your piece.
3. First player to connect **four** pieces horizontally, vertically, or diagonally wins.
4. Click **New game** to reset the board.

## Running it

```bash
dotnet run
```

Then open the URL shown in the console (e.g. `https://localhost:xxxx`).

## Project structure

| File | Responsibility |
|------|----------------|
| `GameState.cs` | All game rules and state: the 42-cell board, turn tracking, piece dropping, win detection, and the move log. Registered as a singleton service in `Program.cs`. |
| `Components/Pages/Board.razor` | The UI: the board grid, drop buttons, status/turn indicator, and the move-history panel. |
| `Components/Pages/Board.razor.css` | Scoped styling for the board and pieces (pure CSS — no image assets required), including a drop animation. |

## Additional feature: Move history

Beyond the base module, this app tracks and displays a **live list of every move made
in the current game**. Each move is recorded in `GameState` as a `GameMove` record
(move number, player, color, column, and row) and rendered in a side panel next to the
board. The list clears automatically when a new game starts.

Because the move-logging lives inside `GameState` rather than the component, the game
rules and the display stay cleanly separated.

## Board indexing (for reference)

The board is a flat `PieceColor[42]`. For any index `i`:

- `column = i % 7` (0–6)
- `row = i / 7` (0 = top, 5 = bottom)

Win detection scans every cell and checks four directions, with edge guards so a run
never wraps around the side of the board.
